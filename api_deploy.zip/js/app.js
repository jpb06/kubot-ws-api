"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const debug = require("debug");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const kubot_dal_1 = require("kubot-dal");
const rsa_provider_1 = require("rsa-provider");
kubot_dal_1.Configuration.Setup('mongodb://127.0.0.1:27017', 'kubot-ts');
rsa_provider_1.Configuration.Setup('127.0.0.1:27017', 'cryptography-db');
const admin_routes_1 = require("./routes/admin.routes");
const guild_routes_1 = require("./routes/guild.routes");
const security_routes_1 = require("./routes/security.routes");
const static_routes_1 = require("./routes/static.routes");
const extends_implementation_middleware_1 = require("./middleware/extends.implementation.middleware");
let app = express();
app.use(cors({
    origin: 'http://localhost:4200',
    optionsSuccessStatus: 200
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(extends_implementation_middleware_1.extendsImplementation);
app.get('/', (req, res) => {
    res.send('Nothing to see here. See /api');
});
app.get('/api/', (req, res) => {
    res.send('This is Kubot-ws API.');
});
admin_routes_1.mapAdminRoutes(app);
guild_routes_1.mapGuildRoutes(app);
security_routes_1.mapSecurityRoutes(app);
static_routes_1.mapStaticRoutes(app);
app.set('port', process.env.PORT || 3000);
var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});
//# sourceMappingURL=app.js.map