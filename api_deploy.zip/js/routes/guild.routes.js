"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Dal = require("kubot-dal");
const permissions_validation_middleware_1 = require("./../middleware/permissions.validation.middleware");
function mapGuildRoutes(app) {
    app.post('/api/kubot/guild', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateId()) {
                return res.answer(400, 'Expecting an id');
            }
            let guild = yield Dal.Manipulation.GuildsStore.get(req.body.id);
            return res.populate(guild);
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
    app.post('/api/kubot/saveguild', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateGuild()) {
                return res.answer(400, 'Expecting a guild');
            }
            let guild = req.body.guild;
            let result = yield Dal.Manipulation.GuildsStore.set(guild);
            if (result) {
                return res.answer(200, 'success');
            }
            else {
                throw Error('Persistence failure: unable to save data');
            }
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
    app.post('/api/kubot/factions', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateId()) {
                return res.answer(400, 'Expecting an id');
            }
            let factions = yield Dal.Manipulation.FactionWatchStore.get(req.body.id);
            return res.populate(factions);
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
    app.post('/api/kubot/savefactions', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateFactions()) {
                return res.answer(400, 'Expecting an array of factions');
            }
            let factions = req.body.factions;
            let result = yield Dal.Manipulation.FactionWatchStore.set(req.body.id, factions);
            if (result) {
                return res.answer(200, 'success');
            }
            else {
                throw Error('Persistence failure: unable to save data');
            }
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
    app.post('/api/kubot/regions', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateId()) {
                return res.answer(400, 'Expecting an id');
            }
            let regions = yield Dal.Manipulation.RegionWatchStore.get(req.body.id);
            return res.populate(regions);
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
    app.post('/api/kubot/saveregions', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateRegions()) {
                return res.answer(400, 'Expecting an array of regions');
            }
            let regions = req.body.regions;
            let result = yield Dal.Manipulation.RegionWatchStore.set(req.body.id, regions);
            if (result) {
                return res.answer(200, 'success');
            }
            else {
                throw Error('Persistence failure: unable to save data');
            }
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
}
exports.mapGuildRoutes = mapGuildRoutes;
//# sourceMappingURL=guild.routes.js.map