"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const jwt = require("jsonwebtoken");
const moment = require("moment");
const Dal = require("kubot-dal");
const rsa_provider_1 = require("rsa-provider");
function mapSecurityRoutes(app) {
    app.post('/api/ws/login', (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateLogin()) {
                return res.answer(400, 'Expecting identifiers');
            }
            let user = yield Dal.Manipulation.SessionStore.get(req.body.login);
            if (user != null && user.password === req.body.password) {
                let keyPair = yield rsa_provider_1.CryptoService.GetKeyPair('kubot-ws');
                let gracePeriod = req.body.expiresIn || 120;
                let expirationDate = moment().add(gracePeriod, 'seconds');
                const jwtBearerToken = jwt.sign({ guild: req.body.login }, keyPair.privateKey, {
                    algorithm: 'RS256',
                    expiresIn: gracePeriod
                });
                return res.status(200).json({
                    status: 200,
                    token: jwtBearerToken,
                    roles: user.roles,
                    expirationDate: JSON.stringify(expirationDate)
                });
            }
            else {
                return res.status(401).json({
                    status: 401,
                    data: null
                });
            }
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
}
exports.mapSecurityRoutes = mapSecurityRoutes;
//# sourceMappingURL=security.routes.js.map