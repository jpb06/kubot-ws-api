"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Dal = require("kubot-dal");
const permissions_validation_middleware_1 = require("./../middleware/permissions.validation.middleware");
function mapAdminRoutes(app) {
    app.post('/api/kubot/admin/setstarsystems', permissions_validation_middleware_1.isAuthenticated, permissions_validation_middleware_1.HasRole('admin'), (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            if (!req.validateStarSystems()) {
                return res.answer(400, 'Expecting a list of star systems');
            }
            let result = yield Dal.Manipulation.StarSystemsStore.set(req.body.starsystems);
            if (result) {
                return res.answer(200, 'success');
            }
            else {
                throw Error('Persistence failure: unable to save data');
            }
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
}
exports.mapAdminRoutes = mapAdminRoutes;
//# sourceMappingURL=admin.routes.js.map