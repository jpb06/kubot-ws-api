"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Dal = require("kubot-dal");
const permissions_validation_middleware_1 = require("./../middleware/permissions.validation.middleware");
function mapStaticRoutes(app) {
    app.post('/api/static/systems', permissions_validation_middleware_1.isAuthenticated, (req, res) => __awaiter(this, void 0, void 0, function* () {
        try {
            let systems = yield Dal.Manipulation.StarSystemsStore.getAll();
            return res.populate(systems);
        }
        catch (error) {
            return res.answer(500, error.message);
        }
    }));
}
exports.mapStaticRoutes = mapStaticRoutes;
//# sourceMappingURL=static.routes.js.map