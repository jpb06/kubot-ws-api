"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Dal = require("kubot-dal");
function extendsImplementation(req, res, next) {
    res.populate = function (data) {
        if (data === undefined) {
            return res.status(404).json({
                status: 404,
                data: null
            });
        }
        else {
            return res.status(200).json({
                status: 200,
                data: data
            });
        }
    };
    res.answer = function (status, message) {
        return res.status(status).json({
            status: status,
            message: message
        });
    };
    req.validateId = function () {
        if (req.body.id === undefined || req.body.id === '') {
            return false;
        }
        return true;
    };
    req.validateLogin = function () {
        if ((req.body.login === undefined || req.body.login === '') ||
            (req.body.password === undefined || req.body.password === '')) {
            return false;
        }
        return true;
    };
    req.validateGuild = function () {
        if (req.body.guild === undefined || !Dal.Types.PersistedTypesValidation.IsGuildConfiguration(req.body.guild)) {
            return false;
        }
        return true;
    };
    req.validateFactions = function () {
        if (req.body.factions === undefined || !Array.isArray(req.body.factions)) {
            return false;
        }
        for (let i = 0; i < req.body.factions.length; i++) {
            if (!Dal.Types.PersistedTypesValidation.IsWatchedFaction(req.body.factions[i])) {
                return false;
            }
        }
        return true;
    };
    req.validateRegions = function () {
        if (req.body.regions === undefined || !Array.isArray(req.body.regions)) {
            return false;
        }
        for (let i = 0; i < req.body.regions.length; i++) {
            if (!Dal.Types.PersistedTypesValidation.IsWatchedRegion(req.body.regions[i])) {
                return false;
            }
        }
        return true;
    };
    req.validateStarSystems = function () {
        if (req.body.starsystems === undefined || !Array.isArray(req.body.starsystems)) {
            return false;
        }
        for (let i = 0; i < req.body.starsystems.length; i++) {
            if (!Dal.Types.PersistedTypesValidation.IsStarSystem(req.body.starsystems[i])) {
                return false;
            }
        }
        return true;
    };
    next();
}
exports.extendsImplementation = extendsImplementation;
//# sourceMappingURL=extends.implementation.middleware.js.map