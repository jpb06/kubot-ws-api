"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const jwt = require("jsonwebtoken");
const rsa_provider_1 = require("rsa-provider");
const Dal = require("kubot-dal");
function verifyHeaders(req, res) {
    let authorizationHeaders = req.headers.authorization || '';
    let chunks = authorizationHeaders.split(' ');
    if (chunks.length === 0 || chunks[0] !== 'Bearer' || chunks[1].length === 0) {
        return '';
    }
    return chunks[1];
}
function isAuthenticated(req, res, next) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let token = verifyHeaders(req, res);
            if (token === '') {
                return res.answer(401, 'Not logged in');
            }
            let keyPair = yield rsa_provider_1.CryptoService.GetKeyPair('kubot-ws');
            let result = jwt.verify(token, keyPair.publicKey);
            res.locals.login = result.guild;
            next();
        }
        catch (error) {
            if (error.name === 'TokenExpiredError') {
                return res.answer(401, 'Token has expired');
            }
            else if (error.name === 'JsonWebTokenError' && error.message.startsWith('jwt subject invalid')) {
                return res.answer(401, 'Invalid token');
            }
            else {
                return res.answer(500, error.message);
            }
        }
    });
}
exports.isAuthenticated = isAuthenticated;
;
function HasRole(role) {
    return function (req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (res.locals.login === null) {
                    return res.answer(401, 'Not authorized');
                }
                let roles = yield Dal.Manipulation.SessionStore.getPermissions(res.locals.login);
                if ((roles === null || !Array.isArray(roles)) || roles.indexOf(role) === -1) {
                    return res.answer(401, 'Not authorized');
                }
                next();
            }
            catch (error) {
                return res.answer(500, error.message);
            }
        });
    };
}
exports.HasRole = HasRole;
//# sourceMappingURL=permissions.validation.middleware.js.map